#include <iostream>
using namespace std;

int main() {
    int followers, likes, comments;
    cin >> followers >> likes >> comments;

    double engagement = (likes + comments) / (double)followers * 100;
    cout << engagement << endl;
    return 0;
}