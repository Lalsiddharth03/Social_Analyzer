import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Youtube, Twitter, Instagram, Search } from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface SocialMetrics {
  followers: number;
  engagement: number;
  posts: number;
  platform: string;
}

function App() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState<SocialMetrics | null>(null);

  const analyzeSocial = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Create AbortController for timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analyze-social`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Unknown error occurred' }));
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setMetrics(data);
      toast.success('Analysis complete!');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to analyze profile';
      console.error('API Error:', errorMessage);
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getPlatformIcon = (platform?: string) => {
    switch (platform) {
      case 'youtube':
        return <Youtube className="w-8 h-8 text-red-600" />;
      case 'twitter':
        return <Twitter className="w-8 h-8 text-blue-400" />;
      case 'instagram':
        return <Instagram className="w-8 h-8 text-pink-600" />;
      default:
        return null;
    }
  };

  const chartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Engagement Rate',
        data: metrics ? [
          metrics.engagement - 1,
          metrics.engagement - 0.5,
          metrics.engagement,
          metrics.engagement + 0.3,
          metrics.engagement + 0.1,
          metrics.engagement + 0.8
        ] : [],
        borderColor: 'rgb(75, 192, 192)',
        tension: 0.1
      }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Social Network Analyzer</h1>
          <div className="flex space-x-4">
            <Youtube className="w-6 h-6" />
            <Twitter className="w-6 h-6" />
            <Instagram className="w-6 h-6" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* URL Input Form */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <form onSubmit={analyzeSocial} className="flex gap-4">
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Enter social media profile URL"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 flex items-center gap-2"
            >
              {loading ? (
                'Analyzing...'
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  Analyze
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results */}
        {metrics && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Metrics Cards */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Profile Metrics</h2>
                {getPlatformIcon(metrics.platform)}
              </div>
              
              <div className="grid grid-cols-1 gap-6">
                <div className="border-t pt-4">
                  <p className="text-sm text-gray-500">Followers</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {metrics.followers.toLocaleString()}
                  </p>
                </div>
                
                <div className="border-t pt-4">
                  <p className="text-sm text-gray-500">Engagement Rate</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {metrics.engagement.toFixed(1)}%
                  </p>
                </div>
                
                <div className="border-t pt-4">
                  <p className="text-sm text-gray-500">Total Posts</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {metrics.posts.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            {/* Engagement Chart */}
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Engagement Trend</h2>
              <Line data={chartData} options={{
                responsive: true,
                plugins: {
                  legend: {
                    position: 'top' as const,
                  },
                  title: {
                    display: false,
                  },
                },
                scales: {
                  y: {
                    beginAtZero: true,
                    title: {
                      display: true,
                      text: 'Engagement Rate (%)'
                    }
                  }
                }
              }} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;