import { createClient } from 'npm:@supabase/supabase-js@2.39.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SocialMetrics {
  followers: number;
  engagement: number;
  posts: number;
  platform: string;
}

// YouTube API functions
async function getYouTubeMetrics(url: string): Promise<SocialMetrics> {
  const YOUTUBE_API_KEY = 'AIzaSyDLNHk4YdfYux1XRFCMjnShb_IBMMkIuy8';
  
  try {
    // Extract channel ID using more robust URL parsing
    let channelId: string | null = null;
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;

    // Handle various YouTube URL formats
    if (pathname.includes('/channel/')) {
      // Direct channel ID URL
      channelId = pathname.split('/channel/')[1]?.split('/')[0] || null;
    } else if (pathname.startsWith('/@')) {
      // Handle handle-based URLs (e.g., youtube.com/@username)
      const handle = pathname.split('/@')[1]?.split('/')[0];
      if (handle) {
        // Get channel by handle
        const handleResponse = await fetch(
          `https://www.googleapis.com/youtube/v3/search?part=id&type=channel&q=${encodeURIComponent(handle)}&key=${YOUTUBE_API_KEY}`
        );
        
        if (!handleResponse.ok) {
          throw new Error(`Failed to fetch channel info: ${handleResponse.statusText}`);
        }
        
        const handleData = await handleResponse.json();
        if (handleData.items?.[0]?.id?.channelId) {
          channelId = handleData.items[0].id.channelId;
        }
      }
    } else if (pathname.includes('/c/') || pathname.includes('/user/')) {
      // Handle custom URLs (e.g., youtube.com/c/username or youtube.com/user/username)
      const customName = pathname.split('/c/')[1]?.split('/')[0] || 
                        pathname.split('/user/')[1]?.split('/')[0];
      if (customName) {
        // Search for channel by custom URL
        const searchResponse = await fetch(
          `https://www.googleapis.com/youtube/v3/search?part=id&type=channel&q=${encodeURIComponent(customName)}&key=${YOUTUBE_API_KEY}`
        );
        
        if (!searchResponse.ok) {
          throw new Error(`Failed to fetch channel info: ${searchResponse.statusText}`);
        }
        
        const searchData = await searchResponse.json();
        if (searchData.items?.[0]?.id?.channelId) {
          channelId = searchData.items[0].id.channelId;
        }
      }
    } else if (pathname.includes('/watch')) {
      // Handle video URLs by extracting channel from video info
      const videoId = urlObj.searchParams.get('v');
      if (videoId) {
        const videoResponse = await fetch(
          `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${YOUTUBE_API_KEY}`
        );
        
        if (!videoResponse.ok) {
          throw new Error(`Failed to fetch video info: ${videoResponse.statusText}`);
        }
        
        const videoData = await videoResponse.json();
        if (videoData.items?.[0]?.snippet?.channelId) {
          channelId = videoData.items[0].snippet.channelId;
        }
      }
    }

    if (!channelId) {
      throw new Error(
        'Could not extract YouTube channel ID. Please use a valid channel URL (e.g., youtube.com/@username, youtube.com/channel/ID, or youtube.com/c/username)'
      );
    }

    // Get channel statistics
    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${channelId}&key=${YOUTUBE_API_KEY}`
    );

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`YouTube API error: ${errorData.error?.message || response.statusText}`);
    }

    const data = await response.json();
    
    if (!data.items || data.items.length === 0) {
      throw new Error('YouTube channel not found. Please check if the channel URL is correct and the channel is public.');
    }

    const stats = data.items[0].statistics;
    
    if (!stats.subscriberCount || !stats.videoCount || !stats.viewCount) {
      throw new Error('Channel metrics are not publicly available. The channel may have hidden their statistics.');
    }

    return {
      followers: parseInt(stats.subscriberCount),
      posts: parseInt(stats.videoCount),
      engagement: (parseInt(stats.viewCount) / parseInt(stats.subscriberCount)) * 100,
      platform: 'youtube'
    };
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`YouTube metrics error: ${error.message}`);
    }
    throw new Error('An unexpected error occurred while fetching YouTube metrics');
  }
}

// Twitter API functions
async function getTwitterMetrics(url: string): Promise<SocialMetrics> {
  const BEARER_TOKEN = 'AAAAAAAAAAAAAAAAAAAAAAUF0gEAAAAA3%2BjX363MS6v2mxe6ILzEKy67LlQ%3D1q4ZWVqpgt4e4vxlZkxbUp06dzBzT9BUyLsFcLFVewCvG5dAk1';
  
  try {
    // Extract username from URL
    const username = url.split('twitter.com/')[1]?.split('/')[0];
    
    if (!username) {
      throw new Error('Invalid Twitter URL: Could not extract username');
    }

    // First, get user ID
    const userResponse = await fetch(
      `https://api.twitter.com/2/users/by/username/${username}`,
      {
        headers: {
          'Authorization': `Bearer ${BEARER_TOKEN}`
        }
      }
    );

    if (!userResponse.ok) {
      const errorData = await userResponse.json();
      throw new Error(`Twitter API error: ${errorData.errors?.[0]?.message || userResponse.statusText}`);
    }

    const userData = await userResponse.json();
    
    if (!userData.data) {
      throw new Error('Twitter user not found');
    }

    // Get user metrics
    const metricsResponse = await fetch(
      `https://api.twitter.com/2/users/${userData.data.id}?user.fields=public_metrics`,
      {
        headers: {
          'Authorization': `Bearer ${BEARER_TOKEN}`
        }
      }
    );

    if (!metricsResponse.ok) {
      const errorData = await metricsResponse.json();
      throw new Error(`Twitter metrics error: ${errorData.errors?.[0]?.message || metricsResponse.statusText}`);
    }

    const metricsData = await metricsResponse.json();
    const metrics = metricsData.data.public_metrics;

    if (!metrics.followers_count || !metrics.tweet_count) {
      throw new Error('Incomplete Twitter metrics data');
    }

    return {
      followers: metrics.followers_count,
      posts: metrics.tweet_count,
      engagement: (metrics.listed_count / metrics.followers_count) * 100,
      platform: 'twitter'
    };
  } catch (error) {
    throw new Error(`Twitter metrics error: ${error.message}`);
  }
}

async function analyzeSocialProfile(url: string): Promise<SocialMetrics> {
  if (!url) {
    throw new Error('URL is required');
  }

  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname.toLowerCase();

    if (domain.includes('youtube.com') || domain.includes('youtu.be')) {
      return await getYouTubeMetrics(url);
    } else if (domain.includes('twitter.com')) {
      return await getTwitterMetrics(url);
    } else if (domain.includes('instagram.com')) {
      // Instagram API requires a more complex authentication process
      // For now, return mock data
      return {
        followers: 250000,
        engagement: 4.7,
        posts: 1000,
        platform: 'instagram'
      };
    } else {
      throw new Error('Unsupported platform. Please use YouTube, Twitter, or Instagram URLs.');
    }
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('Invalid URL')) {
      throw new Error('Invalid URL format. Please provide a valid social media profile URL.');
    }
    throw error;
  }
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url } = await req.json().catch(() => ({}));
    
    if (!url) {
      return new Response(
        JSON.stringify({ 
          error: 'URL is required',
          details: 'Please provide a social media profile URL'
        }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    const metrics = await analyzeSocialProfile(url);

    return new Response(
      JSON.stringify(metrics),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (error) {
    console.error('Analysis error:', error);
    
    return new Response(
      JSON.stringify({ 
        error: error.message,
        details: error instanceof Error ? error.stack : 'Unknown error occurred'
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});